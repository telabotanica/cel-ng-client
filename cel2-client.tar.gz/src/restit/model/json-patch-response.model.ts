export interface JsonPatchResponse {
    op?:string;
    path?:string;
    value?:string;
    from?:string;    
}


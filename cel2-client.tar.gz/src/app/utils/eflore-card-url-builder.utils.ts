import { environment } from '../../environments/environment';

export class EfloreCardUrlBuilder {  
  

  static build(taxoRepoName, taxonId) {
    let url = "";//AppConfig.settings.eflore.baseUrlTemplate
    return url;
  }

}

export class TelaBotanicaProject {
    id: number;
    name: string;
} 

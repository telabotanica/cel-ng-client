

export class TaxoRepo {
  id: number;
  name: string;
}

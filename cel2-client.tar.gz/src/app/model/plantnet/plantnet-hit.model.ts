import { PlantnetSpecies } from "./plantnet-species.model";

export class PlantnetHit {

  score: number;
  species: PlantnetSpecies;

} 

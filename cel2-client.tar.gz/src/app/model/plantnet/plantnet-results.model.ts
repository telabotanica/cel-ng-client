import { PlantnetHit } from "./plantnet-hit.model";

export class PlantnetResults {

  results: PlantnetHit[];

} 

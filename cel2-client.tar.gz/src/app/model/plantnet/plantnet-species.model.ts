

export class PlantnetSpecies {

  scientificNameWithoutAuthor: string;
  scientificNameAuthorship: string;

} 

import { PlantnetResults } from "./plantnet-results.model";

export class PlantnetResponse {

  results: PlantnetResults;

} 

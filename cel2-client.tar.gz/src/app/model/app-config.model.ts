export interface IAppConfig {
    env: {
        name: string;
    };
    api: {
        baseUrl: string;
    }
}
